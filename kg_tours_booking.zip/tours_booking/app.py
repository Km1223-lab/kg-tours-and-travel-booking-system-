from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_mail import Mail, Message
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import stripe
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-change-in-production'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///tours.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Stripe config (replace with your keys)
app.config['STRIPE_PUBLIC_KEY'] = 'pk_test_your_stripe_public_key'
app.config['STRIPE_SECRET_KEY'] = 'sk_test_your_stripe_secret_key'
stripe.api_key = app.config['STRIPE_SECRET_KEY']

# Mail config (replace with your SMTP settings)
app.config['MAIL_SERVER'] = 'smtp.gmail.com'
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'your-email@gmail.com'
app.config['MAIL_PASSWORD'] = 'your-app-password'
app.config['MAIL_DEFAULT_SENDER'] = 'your-email@gmail.com'

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
mail = Mail(app)


# ─── Models ──────────────────────────────────────────────────────────────────

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    bookings = db.relationship('Booking', backref='user', lazy=True)


class Tour(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=False)
    destination = db.Column(db.String(100), nullable=False)
    duration_days = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)
    max_capacity = db.Column(db.Integer, nullable=False)
    image_url = db.Column(db.String(300), default='')
    is_active = db.Column(db.Boolean, default=True)
    departure_date = db.Column(db.DateTime, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    bookings = db.relationship('Booking', backref='tour', lazy=True)

    @property
    def available_spots(self):
        confirmed = Booking.query.filter_by(tour_id=self.id, status='confirmed').count()
        return self.max_capacity - confirmed


class Booking(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    tour_id = db.Column(db.Integer, db.ForeignKey('tour.id'), nullable=False)
    guests = db.Column(db.Integer, default=1)
    total_price = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, confirmed, cancelled
    stripe_payment_id = db.Column(db.String(200), default='')
    special_requests = db.Column(db.Text, default='')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)


@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# ─── Auth Routes ─────────────────────────────────────────────────────────────

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')

        if User.query.filter_by(email=email).first():
            flash('Email already registered.', 'error')
            return redirect(url_for('register'))

        user = User(
            name=name,
            email=email,
            password=generate_password_hash(password)
        )
        db.session.add(user)
        db.session.commit()

        # Send welcome email
        try:
            msg = Message('Welcome to KG Tours & Travel!', recipients=[email])
            msg.html = render_template('emails/welcome.html', user=user)
            mail.send(msg)
        except Exception:
            pass  # Don't block registration if email fails

        flash('Account created! Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        user = User.query.filter_by(email=email).first()

        if user and check_password_hash(user.password, password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page or url_for('index'))

        flash('Invalid email or password.', 'error')

    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))


# ─── Public Routes ────────────────────────────────────────────────────────────

@app.route('/')
def index():
    tours = Tour.query.filter_by(is_active=True).order_by(Tour.departure_date).limit(6).all()
    return render_template('index.html', tours=tours)


@app.route('/tours')
def tours():
    destination = request.args.get('destination', '')
    tours_query = Tour.query.filter_by(is_active=True)
    if destination:
        tours_query = tours_query.filter(Tour.destination.ilike(f'%{destination}%'))
    all_tours = tours_query.order_by(Tour.departure_date).all()
    return render_template('tours.html', tours=all_tours, destination=destination)


@app.route('/tour/<int:tour_id>')
def tour_detail(tour_id):
    tour = Tour.query.get_or_404(tour_id)
    return render_template('tour_detail.html', tour=tour,
                           stripe_public_key=app.config['STRIPE_PUBLIC_KEY'])


# ─── Booking Routes ───────────────────────────────────────────────────────────

@app.route('/book/<int:tour_id>', methods=['GET', 'POST'])
@login_required
def book_tour(tour_id):
    tour = Tour.query.get_or_404(tour_id)
    if request.method == 'POST':
        guests = int(request.form.get('guests', 1))
        special_requests = request.form.get('special_requests', '')
        total = tour.price * guests

        if guests > tour.available_spots:
            flash('Not enough spots available.', 'error')
            return redirect(url_for('tour_detail', tour_id=tour_id))

        booking = Booking(
            user_id=current_user.id,
            tour_id=tour_id,
            guests=guests,
            total_price=total,
            special_requests=special_requests,
            status='pending'
        )
        db.session.add(booking)
        db.session.commit()
        return redirect(url_for('checkout', booking_id=booking.id))

    return render_template('book_tour.html', tour=tour)


@app.route('/checkout/<int:booking_id>')
@login_required
def checkout(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    if booking.user_id != current_user.id:
        flash('Unauthorized.', 'error')
        return redirect(url_for('index'))
    return render_template('checkout.html', booking=booking,
                           stripe_public_key=app.config['STRIPE_PUBLIC_KEY'])


@app.route('/create-payment-intent', methods=['POST'])
@login_required
def create_payment_intent():
    data = request.get_json()
    booking_id = data.get('booking_id')
    booking = Booking.query.get_or_404(booking_id)

    try:
        intent = stripe.PaymentIntent.create(
            amount=int(booking.total_price * 100),  # cents
            currency='usd',
            metadata={'booking_id': booking_id}
        )
        return jsonify({'clientSecret': intent['client_secret']})
    except Exception as e:
        return jsonify({'error': str(e)}), 400


@app.route('/payment-success/<int:booking_id>', methods=['POST'])
@login_required
def payment_success(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    payment_intent_id = request.form.get('payment_intent_id', '')
    booking.status = 'confirmed'
    booking.stripe_payment_id = payment_intent_id
    db.session.commit()

    # Send confirmation email
    try:
        msg = Message('Booking Confirmed – KG Tours & Travel', recipients=[current_user.email])
        msg.html = render_template('emails/booking_confirmation.html',
                                   booking=booking, user=current_user)
        mail.send(msg)
    except Exception:
        pass

    flash('Booking confirmed! Check your email.', 'success')
    return redirect(url_for('my_bookings'))


@app.route('/my-bookings')
@login_required
def my_bookings():
    bookings = Booking.query.filter_by(user_id=current_user.id).order_by(Booking.created_at.desc()).all()
    return render_template('my_bookings.html', bookings=bookings)


@app.route('/cancel-booking/<int:booking_id>', methods=['POST'])
@login_required
def cancel_booking(booking_id):
    booking = Booking.query.get_or_404(booking_id)
    if booking.user_id != current_user.id:
        flash('Unauthorized.', 'error')
        return redirect(url_for('my_bookings'))
    booking.status = 'cancelled'
    db.session.commit()
    flash('Booking cancelled.', 'info')
    return redirect(url_for('my_bookings'))


# ─── Admin Routes ─────────────────────────────────────────────────────────────

def admin_required(f):
    from functools import wraps
    @wraps(f)
    def decorated(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('Admin access required.', 'error')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated


@app.route('/admin')
@login_required
@admin_required
def admin_dashboard():
    total_users = User.query.count()
    total_tours = Tour.query.count()
    total_bookings = Booking.query.count()
    confirmed_bookings = Booking.query.filter_by(status='confirmed').count()
    revenue = db.session.query(db.func.sum(Booking.total_price)).filter_by(status='confirmed').scalar() or 0
    recent_bookings = Booking.query.order_by(Booking.created_at.desc()).limit(10).all()
    return render_template('admin/dashboard.html',
                           total_users=total_users,
                           total_tours=total_tours,
                           total_bookings=total_bookings,
                           confirmed_bookings=confirmed_bookings,
                           revenue=revenue,
                           recent_bookings=recent_bookings)


@app.route('/admin/tours')
@login_required
@admin_required
def admin_tours():
    all_tours = Tour.query.order_by(Tour.created_at.desc()).all()
    return render_template('admin/tours.html', tours=all_tours)


@app.route('/admin/tours/add', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_add_tour():
    if request.method == 'POST':
        tour = Tour(
            name=request.form['name'],
            description=request.form['description'],
            destination=request.form['destination'],
            duration_days=int(request.form['duration_days']),
            price=float(request.form['price']),
            max_capacity=int(request.form['max_capacity']),
            image_url=request.form.get('image_url', ''),
            departure_date=datetime.strptime(request.form['departure_date'], '%Y-%m-%dT%H:%M')
        )
        db.session.add(tour)
        db.session.commit()
        flash('Tour added!', 'success')
        return redirect(url_for('admin_tours'))
    return render_template('admin/tour_form.html', tour=None)


@app.route('/admin/tours/edit/<int:tour_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def admin_edit_tour(tour_id):
    tour = Tour.query.get_or_404(tour_id)
    if request.method == 'POST':
        tour.name = request.form['name']
        tour.description = request.form['description']
        tour.destination = request.form['destination']
        tour.duration_days = int(request.form['duration_days'])
        tour.price = float(request.form['price'])
        tour.max_capacity = int(request.form['max_capacity'])
        tour.image_url = request.form.get('image_url', '')
        tour.departure_date = datetime.strptime(request.form['departure_date'], '%Y-%m-%dT%H:%M')
        tour.is_active = 'is_active' in request.form
        db.session.commit()
        flash('Tour updated!', 'success')
        return redirect(url_for('admin_tours'))
    return render_template('admin/tour_form.html', tour=tour)


@app.route('/admin/tours/delete/<int:tour_id>', methods=['POST'])
@login_required
@admin_required
def admin_delete_tour(tour_id):
    tour = Tour.query.get_or_404(tour_id)
    db.session.delete(tour)
    db.session.commit()
    flash('Tour deleted.', 'info')
    return redirect(url_for('admin_tours'))


@app.route('/admin/bookings')
@login_required
@admin_required
def admin_bookings():
    bookings = Booking.query.order_by(Booking.created_at.desc()).all()
    return render_template('admin/bookings.html', bookings=bookings)


@app.route('/admin/users')
@login_required
@admin_required
def admin_users():
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template('admin/users.html', users=users)


# ─── Seed & Init ─────────────────────────────────────────────────────────────

def seed_data():
    if Tour.query.count() == 0:
        tours = [
            Tour(name='Serengeti Safari Adventure', destination='Tanzania',
                 description='Witness the Great Migration across the vast Serengeti plains. Expert guides, luxury tented camps, and unforgettable wildlife encounters await.',
                 duration_days=7, price=2499, max_capacity=12,
                 image_url='https://images.unsplash.com/photo-1516426122078-c23e76319801?w=800',
                 departure_date=datetime(2026, 7, 15)),
            Tour(name='Amalfi Coast Escape', destination='Italy',
                 description='Cruise the breathtaking Amalfi Coast, explore Positano, Ravello, and Capri. Fine dining, boat tours, and coastal hikes included.',
                 duration_days=5, price=1899, max_capacity=16,
                 image_url='https://images.unsplash.com/photo-1533587851505-d119e13fa0d7?w=800',
                 departure_date=datetime(2026, 8, 3)),
            Tour(name='Machu Picchu & Sacred Valley', destination='Peru',
                 description='Trek the Inca Trail to Machu Picchu, explore the Sacred Valley, and discover ancient Andean cultures with expert archaeologists.',
                 duration_days=8, price=2199, max_capacity=10,
                 image_url='https://images.unsplash.com/photo-1526392060635-9d6019884377?w=800',
                 departure_date=datetime(2026, 9, 10)),
            Tour(name='Northern Lights Iceland', destination='Iceland',
                 description='Chase the Aurora Borealis, soak in geothermal pools, explore glaciers, and experience the raw power of Icelandic nature.',
                 duration_days=6, price=2799, max_capacity=8,
                 image_url='https://images.unsplash.com/photo-1531366936337-7c912a4589a7?w=800',
                 departure_date=datetime(2026, 10, 20)),
            Tour(name='Bali Spiritual Journey', destination='Indonesia',
                 description='Immerse yourself in Balinese culture, visit ancient temples, participate in traditional ceremonies, and relax in jungle retreats.',
                 duration_days=9, price=1599, max_capacity=14,
                 image_url='https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=800',
                 departure_date=datetime(2026, 6, 25)),
            Tour(name='Patagonia Wilderness Trek', destination='Argentina/Chile',
                 description='Hike through Torres del Paine, witness Perito Moreno Glacier, and explore the untouched wilderness at the end of the world.',
                 duration_days=10, price=3199, max_capacity=8,
                 image_url='https://images.unsplash.com/photo-1501854140801-50d01698950b?w=800',
                 departure_date=datetime(2026, 11, 5)),
        ]
        for t in tours:
            db.session.add(t)

    if not User.query.filter_by(email='admin@kgtours.com').first():
        admin = User(name='Admin', email='admin@kgtours.com',
                     password=generate_password_hash('admin123'), is_admin=True)
        db.session.add(admin)

    db.session.commit()


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        seed_data()
    app.run(debug=True)
