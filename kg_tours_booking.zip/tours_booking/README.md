# KG Tours & Travel – Booking System

A full-stack tour booking website built with Flask, SQLite, Stripe, and Flask-Mail.

## Tech Stack
- **Backend:** Python / Flask
- **Database:** SQLite (via SQLAlchemy ORM)
- **Auth:** Flask-Login (hashed passwords)
- **Payments:** Stripe
- **Email:** Flask-Mail (SMTP / Gmail)
- **Frontend:** HTML, CSS, Vanilla JS

## Features
- User registration & login
- Browse and search tours
- Book tours with guest count
- Stripe payment checkout
- Email confirmations (welcome + booking)
- Admin dashboard (tours, bookings, users)
- Cancel bookings

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure settings in `app.py`
Edit the top of `app.py` and replace:
- `your-secret-key-change-in-production` → a random string
- `pk_test_your_stripe_public_key` → your Stripe public key
- `sk_test_your_stripe_secret_key` → your Stripe secret key
- Gmail SMTP settings (username + app password)

### 3. Run the app
```bash
python app.py
```
Visit: http://localhost:5000

The database and sample tour data are created automatically on first run.

## Admin Access
- URL: http://localhost:5000/admin
- Email: `admin@kgtours.com`
- Password: `admin123`
> ⚠️ Change this password after first login in production!

## Stripe Testing
Use Stripe test card: `4242 4242 4242 4242` · Any future date · Any CVC

## Gmail App Password Setup
1. Enable 2FA on your Google account
2. Go to Google Account → Security → App Passwords
3. Generate a password for "Mail" and paste it in `app.py`

## Project Structure
```
tours_booking/
├── app.py                  # Main Flask app + routes + models
├── requirements.txt
├── static/
│   └── css/style.css       # All styles
└── templates/
    ├── base.html            # Navbar + layout
    ├── index.html           # Homepage
    ├── tours.html           # Tours listing
    ├── tour_detail.html     # Single tour page
    ├── book_tour.html       # Booking form
    ├── checkout.html        # Stripe checkout
    ├── my_bookings.html     # User bookings
    ├── login.html
    ├── register.html
    ├── admin/
    │   ├── dashboard.html
    │   ├── tours.html
    │   ├── tour_form.html
    │   ├── bookings.html
    │   └── users.html
    └── emails/
        ├── welcome.html
        └── booking_confirmation.html
```

## Deployment
For production, consider:
- **Railway / Render / Fly.io** for the Flask app
- **PostgreSQL** instead of SQLite (change the DB URI)
- Set `DEBUG=False` and use environment variables for secrets
